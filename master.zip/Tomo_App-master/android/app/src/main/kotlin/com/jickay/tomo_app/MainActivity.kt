package com.jickay.tomo_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
